#!/bin/bash
PATH=/ccc/cont003/home/cerege/laugiema/ORCA/DOMSK/bin:$PATH
export PATH
