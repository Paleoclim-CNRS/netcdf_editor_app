#!/usr/bin/ksh
export PATH=/ccc/cont003/home/cerege/banfielw/CPL/MOZAIC/bin:$PATH
