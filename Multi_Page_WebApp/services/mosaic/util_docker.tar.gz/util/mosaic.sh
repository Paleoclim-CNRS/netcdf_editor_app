#!/bin/bash

set -vx
#limit stacksize 1638400

command=${0}

set -e

grid="yes"
wei="yes"
cote="yes"
ice="yes"
test="no"

while getopts agwciAGWCI opt
do
    case ${opt} in
	(a)  wei="yes" ; cote="yes" ; ice="yes" ; grid="yes" ;;
	(A)  wei="no " ; cote="no"  ; ice="no"  ; grid="no"  ;;
	(g)  grid="yes" ;;
	(G)  grid="no" ;;
	(w)  wei="yes" ;;
	(W)  wei="no" ;;
	(c)  cote="yes" ;;
	(C)  cote="no" ;;
	(i)  ice="yes" ;;
	(I)  ice="no" ;;
	(t)  test="yes" ;;
	(T)  test="no" ;;
    esac
done

shift $(($OPTIND-1));

RunDef=${1:-run.def}

date
dir=$(pwd)
model=$( basename ${dir})
echo ${model}

c_suffix=$(grep c_suffix ${RunDef} | sed 's/c_suffix *= *//' | sed 's/ *//g' )
if [[ "X${c_suffix}" = "X" || "${c_suffix}" = "none" ]] ; then
    c_suffix=''
else
    c_suffix='_'${c_suffix}
fi
echo "c_suffix : " ${c_suffix}

if [ "${grid}" = "yes" ] ; then
    ./grids.sh  -b      ${RunDef} > grids${c_suffix}.out  || ( exit -1 ; )
fi 

if [ "${wei}" = "yes" ] ; then
    time ./mosaic.exe ${RunDef} > mosaic${c_suffix}.out   2>&1 || ( exit -1 ; )
    ./grids.sh -r     ${RunDef} > grids.r${c_suffix}.out       || ( exit -1 ; )
fi

if [ "${cote}" = "yes" ] ; then
    time ./cotes.exe  ${RunDef}   > cotes${c_suffix}.out     2>&1   || ( exit -1 ; )

fi

if [ "${ice}" = "yes" ] ; then
    time ./icestream.exe ${RunDef} > icestream${c_suffix}.out 2>&1  || ( exit -1 ; )
fi

if [ "${test}" = "yes" ] ; then
    ${bin_dir}/tst.exe    ${RunDef} > tst${c_suffix}.out 
    ${bin_dir}/tst.exe -r ${RunDef} > tst_r${c_suffix}.out
fi

date

