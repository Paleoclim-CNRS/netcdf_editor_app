#!/bin/bash
######################
#MSUB -r allwei         # Nom du job
#MSUB -c 8              # Reservation du processus
#MSUB -T 86400          # Limite de temps elapsed du job
#MSUB -e allwei.out     # Sortie standard
#MSUB -o allwei.out     # Sortie standard
#MSUB -n 1
#MSUB -q standard
#MSUB -A gen2212

set -vx
#limit stacksize 1638400

declare SUBMIT_DIR=${SUBMIT_DIR:-${BRIDGE_MSUB_PWD:-${PWD}}}
cd ${SUBMIT_DIR}

command=${0}

RunDef=${1:-run.def}

# module load nco
set -e

pwd

source ./build_names.sh ${PWD}

c_suffix=$(grep c_suffix MOZAIC/${RunDef} | sed 's/c_suffix *= *//' | sed 's/ *//g' )
if [[ "X${c_suffix}" = "X" || "${c_suffix}" = "none" ]] ; then
    c_suffix=''
else
    c_suffix='_'${c_suffix}
fi
echo "c_suffix : " ${c_suffix}

cd ${SUBMIT_DIR}/MOZAIC
./mosaic.sh -a ${RunDef}

cd ${SUBMIT_DIR}/MOZAIC
time ./icestream.exe  ${RunDef}  > icestream${c_suffix}.out 2>&1
#time ./calving.exe   ${RunDef}  > calving${c_suffix}.out   2>&1

if [[ ${CplModel} = eORCA1.*xLMD144x142 ]] ; then
    time ./isf_icb.exe ${RunDef} iceshelf        > isf_icb_iceshelf${c_suffix}.out 2>&1
    time ./isf_icb.exe ${RunDef} iceberg         > isf_icb_iceberg${c_suffix}.out  2>&1
    time ./isf_icb.exe ${RunDef} calving_nosouth > isf_icb_nosouth${c_suffix}.out  2>&1
    time ./isf_icb.exe ${RunDef} calving_full    > isf_icb_full${c_suffix}.out     2>&1
fi


cd ${SUBMIT_DIR}

date

