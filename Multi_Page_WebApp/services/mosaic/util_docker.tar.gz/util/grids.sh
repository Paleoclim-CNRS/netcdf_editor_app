#!/bin/bash
# module load nco

## Construit les fichiers grilles au format NetCDF pour OASIS 3.0
set -x
set -e

lmdz_read="no"
r_lmdz="no"

while getopts rR name
do
    case ${name} in
        r) lmdz_read="yes" ;;
        R) lmdz_read="no"  ;;
    esac
done
shift $((${OPTIND} - 1))

CplDir=$(pwd)

RunDef=${1:-run.def}

#if [ ${#} = 1 ] ; then
#    RESOL=${1}
#else
#    RESOL=$(basename $(dirname $(pwd)) )
#fi

RESOL=$(basename $(dirname $(pwd)) )
source ./build_names.sh ${RESOL}

c_suffix=$(grep c_suffix ${RunDef} | sed 's/c_suffix *= *//' | sed 's/ *//g' )
if [[ "X${c_suffix}" = "X" || "${c_suffix}" = "none" ]] ; then
    c_suffix=''
else
    c_suffix='_'${c_suffix}
fi
echo "c_suffix : " ${c_suffix}


if [ "${lmdz_read}" = "yes" ] ; then
    ./lmdz.exe -r   ${RunDef} > lmdz.r${c_suffix}.out    2>&1
else
    rm -f grids${c_suffix}.nc areas${c_suffix}.nc masks${c_suffix}.nc fracs${c_suffix}.nc lmd.grids${c_suffix}.nc lmd.areas${c_suffix}.nc lmd.masks${c_suffix}.nc lmd.frac${c_suffix}.nc
    if [[ -e restart.nc ]] ; then
	./lmdz.exe -l  ${RunDef} > lmdz${c_suffix}.out      2>&1
    else
	./lmdz.exe -b  ${RunDef} > lmdz${c_suffix}.out     2>&1
    fi
fi

case ${OceName}${OceResol} in
    ( ORCA1 ) JDIM_OCE="-d jpjo,40,331" ;;
    ( *     ) JDIM_OCE=" " ;;
esac

for Type in grids masks areas fracs
do
    if [ -f ${OceModel}.${Type}.nc ]
    then 
	ncks --overwrite ${JDIM_OCE} ${OceModel}.${Type}.nc ${Type}${c_suffix}.nc
    fi
done

# Menage
rm -f tmp_rename.nc masks_temp.nc masks_temp2.nc tmp1.nc tmp2.nc

# Remet la dernière ligne de masque à zéro
# ncap2 ne sais pas travailler avec des variables dont le nom contient un point :-(
cp masks${c_suffix}.nc masks_temp.nc
for grd in torc uorc vorc forc oint ; do
    ncrename -v ${grd}.msk,${grd}_msk masks_temp.nc  tmp_rename.nc ; mv tmp_rename.nc masks_temp.nc
done

ncap2 -O -s "torc_msk(0:0,:)=1;uorc_msk(0:0,:)=1;vorc_msk(0:0,:)=1;forc_msk(0:0,:)=1;oint_msk(0:0,:)=1" masks_temp.nc masks_temp2.nc
mv masks_temp2.nc masks_temp.nc

# Enleve la perio du masque ORCA ...
for grd in torc uorc vorc forc oint ; do
    ncap2 -O -s "${grd}_msk(:,0:0)=1;${grd}_msk(:,${jpoim1}:${jpoim1})=1;${grd}_msk(${jpojm1}:${jpojm1},:)=1"  masks_temp.nc masks_temp2.nc
    mv masks_temp2.nc masks_temp.nc
    case ${OceName}${OceResol} in
	( ORCA2* ) # Demi ligne pour ORCA2
	echo "Demi ligne pour ORCA2"
	ncap2 -O -s "${grd}_msk(${jpojm2}:${jpojm2},${jpoihalf}:${jpoim1})=1"  masks_temp.nc masks_temp2.nc
	mv masks_temp2.nc masks_temp.nc
	;;
    esac
done


# Remet les bons noms
for grd in torc uorc vorc forc oint ; do
    ncrename -v ${grd}_msk,${grd}.msk masks_temp.nc tmp_rename.nc ; mv tmp_rename.nc masks_temp.nc
done
mv masks_temp.nc masks${c_suffix}.nc


if [ ${lmdz_read} = 'yes' ]
then
    LMD_G=LMDZ4.0_${AtmResol}_grid${c_suffix}.nc
    rm -f ${LMD_G} srf.nc lat.nc lon.nc tmp*.nc*

    ncap2 -h -O -s 'ocemask=((OceMask) > 0.5) ; OceFrac=OceMask ; MyMask=short(1-ocemask)' -v o2a.diag${c_suffix}.nc ${LMD_G}
    # Conversion en NetCDF 3 car le rename en HDF5 marche très mal
    nccopy -k classic ${LMD_G} tmp_rename.nc ; mv tmp_rename.nc ${LMD_G}
    
    ncrename -v MyMask,mask ${LMD_G} tmp_rename.nc ; mv tmp_rename.nc ${LMD_G}
    ncrename -d x,lon       ${LMD_G} tmp_rename.nc ; mv tmp_rename.nc ${LMD_G}
    ncrename -d y,lat       ${LMD_G} tmp_rename.nc ; mv tmp_rename.nc ${LMD_G}

    ncks  -A -v "tlmd.lon" lmd.grids${c_suffix}.nc lon.nc
    ncrename -v "tlmd.lon",lon lon.nc tmp_rename.nc ; mv tmp_rename.nc lon.nc
    ncap2    -s 'lon=(lon.avg($jpja))'  lon.nc tmp1.nc
    ncks     -v "tlmd.lat" lmd.grids${c_suffix}.nc lat.nc
    ncrename -v "tlmd.lat",lat lat.nc tmp_rename.nc ; mv tmp_rename.nc lat.nc
    ncap2 -A -s 'lat=(lat.avg($jpia))'  lat.nc tmp1.nc
    ncks  -A -v "tlmd.srf" lmd.areas${c_suffix}.nc tmp1.nc
    ncrename -v "tlmd.srf",aire tmp1.nc  tmp_rename.nc ; mv tmp_rename.nc tmp1.nc
    ncrename -d jpia,lon tmp1.nc  tmp_rename.nc ; mv tmp_rename.nc tmp1.nc
    ncrename -d jpja,lat tmp1.nc  tmp_rename.nc ; mv tmp_rename.nc tmp1.nc
    ncap2 -s 'lon=float(lon) ; lat=float(lat)' tmp1.nc tmp2.nc

    ncks -A tmp2.nc ${LMD_G}
    
    my_date=$( date )

    ncatted -h \
	-a history,global,o,c,"${my_date}: Created by MOSAIC, weight generator for IPSL coupled models\nLMDZ4.0 resolution : ${RESOL_ATM}. Mask comes from NEMO configuration: ORCA${RESOL_OCE}" \
	-a Model,global,o,c,"LMDZ4.0" \
	-a missing_value,mask,d,,    -a long_name,mask,o,c,"Land/Ocean mask"    -a units,mask,o,c,"1/0" \
	-a title,"aire",d,, -a long_name,"aire",c,c,"Grid area" \
	-a title,lon,d,, -a axis,"lon",c,c,"X" -a long_name,"lon",c,c,"Longitude" -a grid_type,"lon",c,c,"P" -a overlap,"lon",c,s,"0" \
	-a title,lat,d,, -a axis,"lat",c,c,"Y" -a long_name,"lat",c,c,"Latitude"  -a grid_type,"lat",c,c,"P" -a overlap,"lat",c,s,"0" \
	${LMD_G}
fi

for file in grids masks areas fracs
do
    ncks -h -A ${atmName}.${file}${c_suffix}.nc ${file}${c_suffix}.nc
    ncatted -h -a Model,global,c,c,"${OceName}" ${file}${c_suffix}.nc
done

rm -f tmp?.nc lat.nc lon.nc

#

