#!/bin/ksh
# JBL -- 03.05.2017

command=$(basename ${0})

usage ()
{
    print "usage: ${command} "
}

# Util=$(dirname ${0})
# MOZAIC=$(dirname ${Util} )
Cpl=/usr/src
Util=${Cpl}/util
CplDir=$(pwd)
Bld=$(dirname ${CplDir})

CplModel=$( basename ${1:-$(pwd)} )
echo CplModel : ${CplModel}

[[ ! -e build_names.sh ]]             && ln -fs ${Util}/build_names.sh    .
source ./build_names.sh ${CplModel}

Version=0

while getopts r:vhc: opt
do
    case ${opt} in
        v) verbose="on" ;;
	c) Suffix=${OPTARG} ;;
	h) usage ; exit 0 ;;
    esac
done

shift $(( ${OPTIND} - 1 ))

echo "command : ${command}"
echo "Util    : ${Util}"
echo "Cpl     : ${Cpl}"
echo "Bld     : ${Bld}"


for Dir in MOZAIC # COTES_MCT ICESTREAM MIXTE
do
    mkdir -p ${Dir}
    rm ${Dir}/orca*${Type} ${Dir}/lmdz* ${Dir}/*.exe

    for Type in areas.nc grids.nc masks.nc fracs.nc nc # areas.r8 grids.r8 masks.i4 masks.i8
    do

	ln -fs ${Bld}/DOMSK/${OceModel}/${OceModel}.${Type} ${Dir}
	ln -fs ${Cpl}/${Dir}/bin/*.exe ${Dir}
    done

done


#ln -fs ${Cpl}/RESTARTS/bin/restarts.exe   ${Cpl}/RESTARTS


[[ ! -e do_link.sh ]]             && ln -fs ${Util}/do_link.sh    .
[[ ! -e MOZAIC/build_names.sh ]]  && ln -fs ${Util}/build_names.sh    MOZAIC
[[ ! -e envoie.sh ]]              && ln -fs ${Util}/envoie.sh     .
[[ ! -e allwei.sh  ]]             && ln -fs ${Util}/allwei.sh     .
[[ ! -e MOZAIC/grids.sh ]]        && ln -fs ${Util}/grids.sh      MOZAIC
[[ ! -e MOZAIC/mosaic.sh ]]       && ln -fs ${Util}/mosaic.sh     MOZAIC
[[ ! -e COTES_MCT/cotes_mct.sh ]] && ln -fs ${Util}/cotes_mct.sh  COTES_MCT

