#!/bin/ksh

DIR_IN=${1}

DIR=${DIR_IN:=$(pwd)}

cd  ${DIR}

rm -f *.out mosaic.out.*
rm -f rmp_*.nc
rm -f lmd.areas.*  lmd.grids.*  lmd.masks.* lmd.fracs.*
rm -f areas.nc grids.nc masks.nc fracs.nc atm.nc oce.nc 
rm -f areas.r8 grids.r8 masks.i4 masks.i8
rm -f mozaic.wa2o* mozaic.wo2a*
rm -f a2o.*diag.nc o2a.*diag.nc dist_cote.nc
rm -f diag1to2.nc diag2to1.nc itarget.nc
rm -f mosaic.e[0-9]*
rm -f poly.* flux_iceberg
rm -f ferret.jnl metafile.plt core.* fort.41
rm -f *~

