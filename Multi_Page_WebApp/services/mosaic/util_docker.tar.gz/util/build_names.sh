#!/bin/sh
#set -x


## Construction des differents noms
export CplModel=$(basename ${1})

echo CplModel : ${CplModel}
export OceModel=$(echo ${CplModel} | sed 's/x.*//' )
export AtmModel=$(echo ${CplModel} | sed "s/${OceModel}x//" )
echo OceModel : ${OceModel}
echo AtmModel : ${AtmModel}

case ${OceModel} in
    ( ORCA*      ) export OceSuffix=$(echo ${OceModel} | sed 's/ORCA//'   )   ;;
    ( PALEORCA*  ) export OceSuffix=$(echo ${OceModel} | sed 's/PALEORCA//'   )   ;;
    ( eORCA*     ) export OceSuffix=$(echo ${OceModel} | sed 's/eORCA//'  )   ;;
    ( GRISLI*    ) export OceSuffix=$(echo ${OceModel} | sed 's/GRISLI//' )   ;;
esac

export OceFullResol=$( echo ${OceSuffix}  | sed 's/_.*//' )
export OceResol=${OceFullResol%%.*}
export OceVers=${OceFullResol//*.}


case ${AtmModel} in
    ( LMD* ) export AtmResol=$(echo ${AtmModel} | sed 's/LMD//'  ) ;;
esac

export OceName=${OceModel%%${OceSuffix}}
export AtmName=${AtmModel%%${AtmResol}}

export atmName=$(echo ${AtmName} | tr 'A-Z' 'a-z' )
export oceName=$(echo ${OceName} | tr 'A-Z' 'a-z' )

export oceModel=${oceName}${OceResol}.${OceVers}
export atmModel=${atmName}${AtmResol}

case ${OceName} in
    ( GRISLI ) export oceName=grn  ;;
esac

case ${OceResol} in
    ( 2 ) export jpoi=182 ; export jpoj=149 ;;
    ( 1 )
    case ${OceName} in
	( ORCA  ) export jpoi=362 ; export jpoj=292 ;;
	( eORCA ) export jpoi=362 ; export jpoj=332 ;;
    esac
    ;;
esac

case ${AtmResol} in
    ( 44x36   ) export jpai=44   ; export jpaj=36   ;;
    ( 96x71   ) export jpai=96   ; export jpaj=71   ;;
    ( 96x95   ) export jpai=96   ; export jpaj=95   ;;
    ( 144x142 ) export jpai=144  ; export jpaj=142  ;;
    ( 280x280 ) export jpai=280  ; export jpaj=280  ;;
    ( ????   ) export jpai=${AtmResol:0:2} ; export jpai=${AtmResol:2:} ;;
    ( ?????  ) export jpai=${AtmResol:0:3} ; export jpai=${AtmResol:3:} ;;
    ( ?????? ) export jpai=${AtmResol:0:3} ; export jpai=${AtmResol:3:} ;;
esac
ResolAtm2D=LMD${jpai}x${jpaj}
ResolAtm2D_nox=LMD${jpai}${jpaj}

CplModel_lmdnox=${OceModel}x${ResolAtm2D_nox}

echo CplModel : ${CplModel} -  ${CplModel_lmdnox}
echo Ocean      : ${OceName} - ${OceResol}.${OceVers} - ${oceName} - ${jpoi}x${jpoj} - ${oceModel}
echo Atmosphere : ${AtmName} - ${AtmResol} - ${atmName} - ${jpai}x${jpaj} - ${atmModel}



(( jpoim1 = jpoi - 1 ))
(( jpojm1 = jpoj - 1 ))
(( jpoihalf = jpoi / 2 ))

(( jpoim2 = jpoi - 2 ))
(( jpojm2 = jpoj - 2 ))


(( jpaim1 = jpai - 1 ))
(( jpajm1 = jpaj - 1 ))
