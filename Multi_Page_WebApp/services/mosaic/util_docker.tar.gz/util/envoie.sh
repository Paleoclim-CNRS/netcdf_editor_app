#!/bin/bash

command=${0}
export Bold=$(    tput bold   ) 
export Unde=$(    tput smul   ) ; export OffUnde=$( tput rmul )
export Stou=$(    tput smso   ) ; export OffStou=$( tput rmso )
export Reve=$(    tput rev    ) 

export Black=$(   tput setf 0 )
export Blue=$(    tput setf 1 )
export Green=$(   tput setf 2 )
export Cyan=$(    tput setf 3 )
export Red=$(     tput setf 4 )
export Magenta=$( tput setf 5 )
export Yellow=$(  tput setf 6 )
export White=$(   tput setf 7 )

export Norm=$(    tput sgr0 )

function usage      {
    echo "usage: ${command} [-c config[=IPSLCM6]] [-L lmdz_levels[=79]] [-5|-6] [-i] [-D] [-r] [-u user]"
    echo "    -r      : send by ssh"
    echo "    -u user : ssh user"
    echo "    -s      : send to igcmg shared space"
    echo "    -D      : cancel debug mode"
    echo "    -i      : create directories"
}

function print_exe  { echo ${Bold}"Running :"${Norm}${Green}" ${*}"${Norm} ; ${*} ; }

function print_test { echo ${Bold}"Will run :"${Norm} ${*} ; }

function R_COPY_local {
    if [[ -f ${1} ]] ; then ${CHECK} rsync -rulptv -P ${1} ${2}
    else               	    echo ${Red}"Pas trouve : ${1}"${Norm}
    fi
}
function R_COPY_remote {
    if [[ -f ${1} ]] ; then ${CHECK} rsync -rulptv -e ssh -P ${1} p86ipsl@curie:${2}
    else         	    echo ${Red}"Pas trouve : ${1}"${Norm}
    fi
}
function R_DO_local  { ${CHECK} ${*} ; }
function R_DO_remote { ${CHECK} ssh p86ipsl@curie ${*} ; }

# print_exe ls -al
# print_test ls
# exit

RunDef=run.def

c_suffix=$(grep c_suffix MOZAIC/${RunDef} | sed 's/c_suffix *= *//' | sed 's/ *//g' )
if [[ "X${c_suffix}" = "X" || "${c_suffix}" = "none" ]] ; then
    c_suffix=''
else
    c_suffix='_'${c_suffix}
fi
echo "c_suffix : " ${c_suffix}

# Process command line options

create_igcm="no"

#R_USER=igcmg
R_USER=igcmg
T_IPSL=IPSLCM6
ver_num=""
CHECK=print_test
R_COPY=R_COPY_local ; R_DO=R_DO_local
RESOL_ATM_Z=none

#set -vx

# Traitement de la ligne de commande
while [[ ${#} > 0 ]] ; do
    case ${1} in
	( -- ) shift ; break ;;
	( -h ) usage ; exit 0      ;;
	( -c ) shift ; T_IPSL=${1}    ;;
	( -r ) R_COPY=R_COPY_remote ; R_DO=R_DO_remote ; R_USER=p86ipsl   ;;
	( -s ) R_USER=igcmg ;;
	( -u ) shift ; R_USER=${1} ;;
	( -i ) create_igcm="yes"   ;;
	( -5 ) T_IPSL=IPSLCM5A     ;;
	( -5A) T_IPSL=IPSLCM5A     ;;
	( -5A2) T_IPSL=IPSLCM5A2     ;;
	( -6 ) T_IPSL=IPSLCM6      ;;
	( -L ) shift ; RESOL_ATM_Z=${1}  ;; 
	( -d ) CHECK="print_test"  ;;
	( -D ) CHECK="print_exe"   ;;
	( -X ) delete="yes"        ;;
	( -v | --verbose ) set -o verbose ; local l_verbose="yes" ;;
	( -x | --verbose ) set -o xtrace  ; local l_xtrace="yes"  ;;
	( -vx | --xv ) set -o xtrace ; set +o verbose  ; local l_xtrace="yes" l_verbose="yes"  ;;
	( * ) echo "Unknown option ${1}" ; exit 1 ;;
    esac
    shift
done

#set +vx

RESOL=$(basename $(pwd))
source build_names.sh ${RESOL}

# Warning
#if [[ "${CplModel}" = "ORCA2.3xLMD9695" && "${version}" = "no" ]] ; then
#    version="yes" ; shift ; version_num=1
#    echo " "
#    echo ${Red}"\!/ Numero de version force a 1 \!/"${Norm}
#    echo " "
#fi

if [[ "${RESOL_ATM_Z}" = "none" ]] ; then
    case ${CplModel} in
	( ORCA2.3xLMD96x95    ) RESOL_ATM_Z=39 ;;
	( ORCA1.?xLMD144x142  ) RESOL_ATM_Z=79 ;;
	( eORCA1.?xLMD96x95   ) RESOL_ATM_Z=39 ;;
	( eORCA1.?xLMD144x142 ) RESOL_ATM_Z=79 ;;
	( *                   ) RESOL_ATM_Z=none ;;
    esac
    echo " "
    echo ${Red}"\!/Nombre de niveaux atmosphere force a : ${RESOL_ATM_Z} \!/"${Norm}
    echo " "
fi
if [[ "${RESOL_ATM_Z}" = "none" ]] ; then
    echo " "
    echo ${Red}"\!/Grosse erreur \!/"${Norm}
    echo " "
fi

echo ${Bold}"RESOL : "${Norm}${Blue}${RESOL} ${Norm}
RESOL_DIR=${RESOL}

RESTART_CPL=RESTARTS/${OceModel}x${AtmModel}  #${RESOL_ATM_Z}

echo Restart CPL : ${RESTART_CPL}

RESOL_ATM_2D=LMD${jpai}x${jpaj}
echo ResolAtm2D : ${ResolAtm2D}

# R_IGCM_T=$(ccc_home -W -u ${R_USER})/IGCM
R_IGCM_T=/home/${R_USER}/IGCM
R_IGCM=${R_IGCM:-${R_IGCM_T}}

echo ${Bold}"R_IGCM :"${Norm}${Blue} ${R_IGCM} ${Norm}

[[ -w ./ ]] && chmod -R a+rX .

BC_CPL=CPL/${T_IPSL}/${CplModel_lmdnox}
ATMX=ATM/START/${CplModel}
ATM=ATM/START/${CplModel_lmdnox}
CPL=CPL/${T_IPSL}/${CplModel_lmdnox}


if [[ "${delete}" = "yes" ]] ; then
    for dir in ${BC_CPL} ${ATM} ${CPL} ; do
	${R_DO} rm -r ${R_IGCM}/${dir}
    done

    exit 0
fi

if [[ "${create_igcm}" = "yes" ]] ; then
    for dir in ${ATM} ${CPL} ; do
	if [[ ! -d  ${R_IGCM}/${dir} ]] ; then
	    ${R_DO} mkdir --mode=766 --parents --verbose    ${R_IGCM}/${dir}
	    ${R_DO} chmod -R a+rX                           ${R_IGCM}/${dir}
	fi
	# #lien ${R_IGCM}/STORAGE/INIT/ATM/LMDZ/IPSLCM6/ORCA1.0xLMD144x142x[3,5,7]9 IGCM/STORAGE/INIT/ATM/IPSLCM6/ORCA1.0xLMD144x142x[3,5,7]9
	# if [[ ! -f ${R_IGCM}/${dir} ]] ; then
	#     ${R_DO} mkdir --mode=766 --parents --verbose    $(dirname ${R_IGCM}/${dir})
	#     ${R_DO} chmod -R a+rX                           $(dirname ${R_IGCM}/${dir})
	#     ${R_DO} ln -s ${R_IGCM}/STORAGE/${dir}          $(dirname ${R_IGCM}/${dir})/
	# fi
	#${R_DO} chmod -R a+rX ${R_IGCM}/STORAGE/${dir}/ $(dirname ${R_IGCM}/${dir})/
    done
fi

case ${T_IPSL} in

    ( "IPSLCM5A" )
    for file in MOZAIC/grids${c_suffix}.nc MOZAIC/areas${c_suffix}.nc MOZAIC/masks${c_suffix}.nc MOZAIC/mozaic.*${c_suffix}.nc 
    do 
	l_file=$(basename ${file})
	${R_COPY} ${file} ${R_IGCM}/${BC_CPL}/${l_file}
    done
    ${R_COPY} MOZAIC/run.def ${R_IGCM}/${BC_CPL}/run${c_suffix}.def
    
    ${R_COPY} MOZAIC/o2a.diag${c_suffix}.nc ${R_IGCM}/${ATM}/o2a${c_suffix}.nc
    ${R_COPY} RESTARTS/sstocean_P0_*_CM5.nc ${R_IGCM}/${CPL}/sstoc.nc
    ${R_COPY} RESTARTS/flxatmos_P0_*_CM5.nc ${R_IGCM}/${CPL}/flxat.nc
    
    ;;
    
    ( "IPSLCM5A2" ) 
    for file in MOZAIC/grids${c_suffix}.nc MOZAIC/areas${c_suffix}.nc MOZAIC/masks${c_suffix}.nc MOZAIC/rmp_tlmd_to_torc_MOSAIC${c_suffix}.nc MOZAIC/rmp_tlmd_to_torc_MOSAIC_calvin${c_suffix}.nc MOZAIC/rmp_torc_to_tlmd_MOSAIC${c_suffix}.nc MOZAIC/rmp_tlmd_to_torc_MOSAIC_rivflu${c_suffix}.nc MOZAIC/rmp_tlmd_to_torc_MOSAIC_calving_iceshelf${c_suffix}.nc MOZAIC/rmp_tlmd_to_torc_MOSAIC_calving_iceberg${c_suffix}.nc MOZAIC/rmp_tlmd_to_torc_MOSAIC_calving_nosouth${c_suffix}.nc MOZAIC/rmp_tlmd_to_torc_MOSAIC_calving_full${c_suffix}.nc
    do
	if [[ -f ${file} ]] ; then
	    l_file=$(basename ${file})
	    ${R_COPY} ${file} ${R_IGCM}/${BC_CPL}/${l_file}
	fi
    done

    ${R_COPY} MOZAIC/run.def  ${R_IGCM}/${BC_CPL}/run${c_suffix}.def

    ncks -O -v COCALVIN ${RESTART_CPL}/flxatmos_P0_*${jpai}x*${jpaj}_CM5A2.nc ${RESTART_CPL}/icbrg_P0_${jpai}x${jpaj}_CM5A2.nc
    ncks -O -v COCALVIN ${RESTART_CPL}/flxatmos_P0_*${jpai}x*${jpaj}_CM5A2.nc ${RESTART_CPL}/icshf_P0_${jpai}x${jpaj}_CM5A2.nc
    
    ${R_COPY} MOZAIC/o2a.diag${c_suffix}.nc                         ${R_IGCM}/${ATM}/o2a${c_suffix}.nc
    ${R_COPY} ${RESTART_CPL}/sstocean_P0_*${jpoi}x*${jpoj}_CM5A2.nc ${R_IGCM}/${CPL}/sstoc${c_suffix}.nc
    ${R_COPY} ${RESTART_CPL}/flxatmos_P0_*${jpai}x*${jpaj}_CM5A2.nc ${R_IGCM}/${CPL}/flxat${c_suffix}.nc
    ${R_COPY} ${RESTART_CPL}/icbrg_P0_${jpai}x${jpaj}_CM5A2.nc      ${R_IGCM}/${CPL}/icbrg${c_suffix}.nc
    ${R_COPY} ${RESTART_CPL}/icshf_P0_${jpai}x${jpaj}_CM5A2.nc      ${R_IGCM}/${CPL}/icshf${c_suffix}.nc

    ;;

    ( "IPSLCM6" ) 
    for file in MOZAIC/grids${c_suffix}.nc MOZAIC/areas${c_suffix}.nc MOZAIC/masks${c_suffix}.nc MOZAIC/rmp_tlmd_to_torc_MOSAIC${c_suffix}.nc MOZAIC/rmp_tlmd_to_torc_MOSAIC_calvin${c_suffix}.nc MOZAIC/rmp_torc_to_tlmd_MOSAIC${c_suffix}.nc MOZAIC/rmp_tlmd_to_torc_MOSAIC_rivflu${c_suffix}.nc MOZAIC/rmp_tlmd_to_torc_MOSAIC_calving_iceshelf${c_suffix}.nc MOZAIC/rmp_tlmd_to_torc_MOSAIC_calving_iceberg${c_suffix}.nc MOZAIC/rmp_tlmd_to_torc_MOSAIC_calving_nosouth${c_suffix}.nc MOZAIC/rmp_tlmd_to_torc_MOSAIC_calving_full${c_suffix}.nc
    do
	if [[ -f ${file} ]] ; then
	    l_file=$(basename ${file})
	    ${R_COPY} ${file} ${R_IGCM}/${BC_CPL}/${l_file}
	fi
    done

    ${R_COPY} MOZAIC/run.def  ${R_IGCM}/${BC_CPL}/run${c_suffix}.def

    ncks -O -v COCALVIN ${RESTART_CPL}/flxatmos_P0_*${jpai}x*${jpaj}_CM6.nc ${RESTART_CPL}/icbrg_P0_${jpai}x${jpaj}_CM6.nc
    ncks -O -v COCALVIN ${RESTART_CPL}/flxatmos_P0_*${jpai}x*${jpaj}_CM6.nc ${RESTART_CPL}/icshf_P0_${jpai}x${jpaj}_CM6.nc
    
    ${R_COPY} MOZAIC/o2a.diag${c_suffix}.nc                       ${R_IGCM}/${ATMX}/o2a${c_suffix}.nc
    ${R_COPY} ${RESTART_CPL}/sstocean_P0_*${jpoi}x*${jpoj}_CM6.nc ${R_IGCM}/${CPL}/sstoc${c_suffix}.nc
    ${R_COPY} ${RESTART_CPL}/flxatmos_P0_*${jpai}x*${jpaj}_CM6.nc ${R_IGCM}/${CPL}/flxat${c_suffix}.nc
    ${R_COPY} ${RESTART_CPL}/icbrg_P0_${jpai}x${jpaj}_CM6.nc      ${R_IGCM}/${CPL}/icbrg${c_suffix}.nc
    ${R_COPY} ${RESTART_CPL}/icshf_P0_${jpai}x${jpaj}_CM6.nc      ${R_IGCM}/${CPL}/icshf${c_suffix}.nc

    ;;

esac

if [[ "${create_igcm}" = "yes" ]] ; then
    for dir in ${BC_CPL} ${ATM} ${CPL} ; do
	${R_DO} chmod -R a+rX ${R_IGCM}/${dir} ${R_IGCM}/${dir}
    done
fi

if [[ "${R_USER}" = "igcmg" ]] ; then
    ${R_DO} "cd ${R_IGCM}/.. ; ccc_shspace_chmod userread IGCM"
fi

[[ X${l_verbose} = "Xyes" ]] && set +o verbose
[[ X${l_xtrace}  = "Xyes" ]] && set +o xtrace
