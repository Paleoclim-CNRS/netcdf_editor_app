#!/bin/bash

set -vx
#limit stacksize 1638400

declare SUBMIT_DIR=${SUBMIT_DIR:-${BRIDGE_MSUB_PWD:-${PWD}}}
cd ${SUBMIT_DIR}

command=${0}

set -e


time ./cotes_mct.exe      > cotes_mct.out     2>&1 
for TYPE in areas grids masks fracs
do
    ncks -A lmdz_${TYPE}_runoff_conserv.nc ../MOZAIC/${TYPE}.nc
    ncks -A orca_${TYPE}_runoff_conserv.nc ../MOZAIC/${TYPE}.nc
done



date

